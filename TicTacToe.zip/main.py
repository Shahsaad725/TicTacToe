
from kivy.app import App
from kivy.config import Config
from kivy.core.window import Window
from kivy.uix.gridlayout import GridLayout
from kivy.uix.button import Button
from kivy.uix.popup import Popup
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.label import Label
from kivy.clock import Clock
from kivy.metrics import sp
from kivy.graphics import Color, Rectangle, RoundedRectangle, Line, Ellipse
from kivy.animation import Animation
from kivy.core.audio import SoundLoader
from kivy.uix.image import Image
from kivy.uix.progressbar import ProgressBar
from kivy.core.text import LabelBase
from kivy.storage.jsonstore import JsonStore

# Optional Android vibration support
try:
    from plyer import vibrator
except ImportError:
    vibrator = None

Config.set("graphics", "rotation", "0")


# --------------------------------------------------
# SETTINGS BUTTON
# --------------------------------------------------

class SettingsButton(FloatLayout):

    def __init__(self, on_press=None, **kwargs):
        super().__init__(**kwargs)
        self.on_press_callback = on_press

        with self.canvas.before:
            self.bg_color_instruction = Color(0.2, 0.3, 0.5, 1)
            self.bg = RoundedRectangle(
                pos=self.pos,
                size=self.size,
                radius=[sp(10)]
            )

        self.bind(pos=self.update_bg, size=self.update_bg)

        self.gear_icon = Image(
            source="icons/gear_icon.png",
            size_hint=(None, None),
            size=(sp(35), sp(35)),
            pos_hint={"center_x": 0.5, "center_y": 0.5}
        )
        self.add_widget(self.gear_icon)

    def update_bg(self, instance, value):
        self.bg.pos = instance.pos
        self.bg.size = instance.size

    def on_touch_down(self, touch):
        if self.collide_point(*touch.pos):
            if self.on_press_callback:
                self.on_press_callback(self)
            return True
        return super().on_touch_down(touch)


# --------------------------------------------------
# MAIN GAME
# --------------------------------------------------

LabelBase.register(
    name="ArabicFont",
    fn_regular="fonts/NotoSansArabic-Regular.ttf"
)

LabelBase.register(
    name="EnglishFont",
    fn_regular="fonts/NotoSans-Regular.ttf"
)

class TicTacToe(App):

    def build(self):

        try:
            Window.rotation = 0
        except (AttributeError, NotImplementedError):
            pass

        # Audio

        # Saved preferences
        self.settings_store = JsonStore("settings.json")
        
        self.dark_theme = True
        self.sound_enabled = True
        self.music_enabled = True
        
        if self.settings_store.exists("preferences"):
        	saved_settings = self.settings_store.get("preferences")
        	self.dark_theme = saved_settings.get("dark_theme", True)
        	self.sound_enabled = saved_settings.get("sound_enabled", True)
        	self.music_enabled = saved_settings.get("music_enabled", True)

        self.apply_theme_colors()


        # Audio
        self.tap_sound = SoundLoader.load("sounds/tap.wav")
        self.win_sound = SoundLoader.load("sounds/win.wav")
        self.draw_sound = SoundLoader.load("sounds/draw.wav")
        
        self.background_music = SoundLoader.load(
    "sounds/background.mp3"
    )
        if self.background_music:
        	self.background_music.loop = True
        	self.background_music.volume = 0.25
        
        if self.music_enabled:
            self.background_music.play()

        # Vibration
        self.vibration_enabled = True

        # Game state
        self.game_over = False
        self.current_player = "X"
        self.last_winner = None
        self.x_score = 0
        self.o_score = 0
        self.dict = {i: " " for i in range(9)}

        self.winning_combinations = [
            (0, 1, 2), (3, 4, 5), (6, 7, 8),
            (0, 3, 6), (1, 4, 7), (2, 5, 8),
            (0, 4, 8), (2, 4, 6)
        ]

        # Main layout
        main_layout = FloatLayout()
        self.main_layout = main_layout

        with main_layout.canvas.before:
            self.background_color = Color(*self.bg_color)
            self.bg = Rectangle(
                pos=main_layout.pos,
                size=main_layout.size
            )

        main_layout.bind(size=self.update_bg, pos=self.update_bg)

        # Centered title
        self.title_label = Label(
            text="TIC TAC TOE",
            font_size=sp(32),
            bold=True,
            color=self.text_color,
            size_hint=(1, 0.12),
            pos_hint={"center_x": 0.5, "top": 0.98},
            halign="center",
            valign="middle"
        )

        self.settings_button = SettingsButton(
            on_press=self.open_settings,
            size_hint=(None, None),
            size=(sp(45), sp(45)),
            pos_hint={"center_x": 0.9, "top": 0.98}
            )

        self.settings_button.bg_color_instruction.rgba = self.cell_color

        self.player_label = Label(
            text="Player X's turn",
            font_size=sp(24),
            bold=True,
            color=(0.2, 0.7, 1, 1),
            size_hint=(1, 0.08),
            pos_hint={"center_x": 0.5, "top": 0.84}
        )

        self.score_label = Label(
            text="Player X: 0        Player O: 0",
            font_size=sp(22),
            bold=True,
            color=self.text_color,
            size_hint=(1, 0.08),
            pos_hint={"center_x": 0.5, "top": 0.76}
        )

        main_layout.add_widget(self.title_label)
        main_layout.add_widget(self.settings_button)
        main_layout.add_widget(self.player_label)
        main_layout.add_widget(self.score_label)

        self.board = self.create_board()
        main_layout.add_widget(self.board)

        # Keep the game ready, but do not show it yet
        self.main_layout = main_layout

        # Create the splash screen
        self.splash_screen = FloatLayout()

        with self.splash_screen.canvas.before:
            Color(*self.bg_color)
            self.splash_bg = Rectangle(
                pos=self.splash_screen.pos,
                size=self.splash_screen.size
            )

        self.splash_screen.bind(
            pos=self.update_splash_bg,
            size=self.update_splash_bg
        )

        # App logo
        self.logo = Image(
            source="icons/opening_logo.png",
            size_hint=(None, None),
            size=(sp(180), sp(180)),
            pos_hint={"center_x": 0.5, "center_y": 0.58},
            opacity=0,
            allow_stretch=True,
            keep_ratio=True
        )

        self.splash_screen.add_widget(self.logo)
        
        # App title beneath the logo
        # Main title
        self.splash_title = Label(
            text="TicTacToe",
            font_size=sp(24),
            bold=True,
            color=self.text_color,
            size_hint=(1, None),
            height=sp(35),
            pos_hint={"center_x": 0.85, "center_y": 0.50}
            )

        # Your name
        self.splash_name = Label(
            text="[font=EnglishFont]SA[/font][font=ArabicFont]ع[/font][font=EnglishFont]DO[/font]",
            markup=True,
            font_size=sp(17),
            bold=False,
            color=(0.1, 0.61, 1, 1),
            size_hint=(1, None),
            height=sp(25),
            pos_hint={"center_x": 0.5, "center_y": 0.47}
            )

        

        self.splash_title.bind(
            size=lambda instance, value:
            setattr(instance, "text_size", value)
            )
            
            
        self.splash_screen.add_widget(self.splash_title)
        self.splash_screen.add_widget(self.splash_name)

        #self.splash_screen.add_widget(self.splash_title)

        # Loading text
        self.loading_label = Label(
            text="Loading...",
            font_size=sp(16),
            color=self.text_color,
            size_hint=(1, None),
            height=sp(30),
            pos_hint={"center_x": 0.5, "center_y": 0.35},
            opacity=0
        )

        self.splash_screen.add_widget(self.loading_label)

        # Loading bar
        self.loading_bar = ProgressBar(
            max=100,
            value=0,
            size_hint=(0.65, None),
            height=sp(6),
            pos_hint={"center_x": 0.5, "center_y": 0.28}
        )

        self.splash_screen.add_widget(self.loading_bar)

        Clock.schedule_once(self.start_splash_animation, 0.2)

        return self.splash_screen

    # --------------------------------------------------
    # THEME COLORS
    # --------------------------------------------------

    def apply_theme_colors(self):

        if self.dark_theme:
            self.bg_color = (0.06, 0.08, 0.15, 1)
            self.cell_color = (0.19, 0.22, 0.30, 1)
            self.text_color = (1, 1, 1, 1)
            self.popup_bg_color = (0.18, 0.21, 0.30, 1)
            self.popup_text_color = (1, 1, 1, 1)
            self.settings_button_color = (0.25, 0.36, 0.55, 1)
        else:
            self.bg_color = (0.94, 0.95, 0.98, 1)
            self.cell_color = (0.82, 0.85, 0.91, 1)
            self.text_color = (0.08, 0.10, 0.17, 1)
            self.popup_bg_color = (0.97, 0.98, 1, 1)
            self.popup_text_color = (0.08, 0.10, 0.17, 1)
            self.settings_button_color = (0.65, 0.73, 0.90, 1)

    # --------------------------------------------------
    # VIBRATION
    # --------------------------------------------------

    def vibrate(self, duration=0.08):

        if not self.vibration_enabled or vibrator is None:
            return

        try:
            if vibrator.exists():
                vibrator.vibrate(time=duration)
        except Exception:
            # Continue playing if vibration is unavailable.
            pass

    # --------------------------------------------------
    # CREATE THEMED PANEL
    # --------------------------------------------------

    def style_panel(self, layout):

        with layout.canvas.before:
            layout.panel_color_instruction = Color(
                *self.popup_bg_color
            )
            layout.panel_background = RoundedRectangle(
                pos=layout.pos,
                size=layout.size,
                radius=[sp(16)]
            )

        def update_panel(instance, value):
            instance.panel_background.pos = instance.pos
            instance.panel_background.size = instance.size

        layout.bind(pos=update_panel, size=update_panel)

    def refresh_panel(self, layout):
        if hasattr(layout, "panel_color_instruction"):
            layout.panel_color_instruction.rgba = self.popup_bg_color

    # --------------------------------------------------
    # APPLY THEME EVERY TIME IT CHANGES
    # --------------------------------------------------

    def apply_theme(self):

        self.apply_theme_colors()
        self.background_color.rgba = self.bg_color

        self.title_label.color = self.text_color
        self.splash_title.color = self.text_color
        self.settings_button.bg_color_instruction.rgba = self.cell_color
        self.score_label.color = self.text_color

        self.player_label.color = (
            (0.2, 0.7, 1, 1)
            if self.current_player == "X"
            else (1, 0.3, 0.3, 1)
        )

        # Update every board cell
        if hasattr(self, "board"):
            for cell in self.board.children:
                cell.bg_rect_color.rgba = self.cell_color

                if cell.text == "X":
                    cell.color = (0.2, 0.7, 1, 1)
                elif cell.text == "O":
                    cell.color = (1, 0.3, 0.3, 1)
                else:
                    cell.color = self.text_color

        # Update settings popup immediately
        if getattr(self, "settings_popup", None):
            self.refresh_panel(self.settings_layout)
            self.settings_title_label.color = self.popup_text_color
            self.style_settings_controls()

        # Update the end-of-round popup immediately
        if getattr(self, "end_popup", None):
            self.refresh_panel(self.end_layout)
            self.end_heading.color = self.popup_text_color
            self.style_end_controls()

    # --------------------------------------------------
    # CREATE BOARD
    # --------------------------------------------------

    def create_board(self):

        board = GridLayout(
            cols=3,
            rows=3,
            spacing=sp(5),
            padding=sp(10),
            size_hint=(0.9, 0.42),
            pos_hint={"center_x": 0.5, "center_y": 0.43}
        )

        for i in range(9):
            button = Button(
                text=" ",
                font_size=sp(42),
                bold=True,
                background_normal="",
                background_down="",
                background_color=(0, 0, 0, 0),
                color=self.text_color
            )

            with button.canvas.before:
                button.bg_rect_color = Color(*self.cell_color)
                button.bg_rect = RoundedRectangle(
                    pos=button.pos,
                    size=button.size,
                    radius=[sp(12)]
                )

            button.bind(
                pos=self.update_button_bg,
                size=self.update_button_bg
            )

            button.index = i
            button.bind(on_press=self.button_pressed)
            board.add_widget(button)

        return board

    # --------------------------------------------------
    # GAME LOGIC
    # --------------------------------------------------

    def button_pressed(self, button):

        if self.game_over or self.dict[button.index] != " ":
            return

        self.vibrate(0.04)

        if self.sound_enabled and self.tap_sound:
            self.tap_sound.stop()
            self.tap_sound.play()

        button.text = self.current_player
        button.font_size = sp(10)

        Animation(
            font_size=sp(42),
            duration=0.18,
            transition="out_back"
        ).start(button)

        button.color = (
            (0.2, 0.7, 1, 1)
            if self.current_player == "X"
            else (1, 0.3, 0.3, 1)
        )

        self.dict[button.index] = self.current_player

        if self.check_winner():

            self.game_over = True
            self.last_winner = self.current_player
            self.vibrate(0.35)

            if self.sound_enabled and self.win_sound:
                self.win_sound.stop()
                self.win_sound.play()

            if self.current_player == "X":
                self.x_score += 1
            else:
                self.o_score += 1

            self.update_score()

            self.player_label.text = (
                "Player " + self.current_player + " wins!"
            )
            self.player_label.color = button.color

            Clock.schedule_once(self.show_winner_popup, 0.8)
            return

        if " " not in self.dict.values():

            self.game_over = True
            self.vibrate(0.18)

            if self.sound_enabled and self.draw_sound:
                self.draw_sound.stop()
                self.draw_sound.play()

            Clock.schedule_once(self.show_draw_popup, 0.8)
            return

        self.current_player = (
            "O" if self.current_player == "X" else "X"
        )

        self.player_label.text = (
            "Player " + self.current_player + "'s turn"
        )
        self.player_label.color = (
            (0.2, 0.7, 1, 1)
            if self.current_player == "X"
            else (1, 0.3, 0.3, 1)
        )

    # --------------------------------------------------
    # WINNER CHECK
    # --------------------------------------------------

    def check_winner(self):

        for combination in self.winning_combinations:
            if all(
                self.dict[index] == self.current_player
                for index in combination
            ):

                for index in combination:
                    button = self.board.children[8 - index]
                    self.set_button_bg_color(
                        button, (0.05, 0.45, 0.15, 1)
                    )

                self.draw_winning_line(combination)
                return True

        return False

    # --------------------------------------------------
    # END POPUPS
    # --------------------------------------------------

    def show_winner_popup(self, dt):
        self.show_end_popup(
            "Player " + self.last_winner + " Wins!"
        )

    def show_draw_popup(self, dt):
        self.show_end_popup("It's a Draw!")

    def show_end_popup(self, message):

        layout = BoxLayout(
            orientation="vertical",
            spacing=sp(12),
            padding=sp(14)
        )
        self.end_layout = layout
        self.style_panel(layout)

        # Use a real Label instead of Popup's built-in title.
        self.end_heading = Label(
            text=message,
            font_size=sp(23),
            bold=True,
            color=self.popup_text_color,
            size_hint=(1, 0.42),
            halign="center",
            valign="middle"
        )
        self.end_heading.bind(
            size=lambda instance, value:
            setattr(instance, "text_size", value)
        )
        layout.add_widget(self.end_heading)

        buttons_row = BoxLayout(
            orientation="horizontal",
            spacing=sp(8)
        )

        play_again = Button(
            text="Play Again",
            font_size=sp(13),
            bold=True,
            background_normal="",
            background_color=(0.05, 0.45, 0.15, 1),
            color=(1, 1, 1, 1)
        )

        new_match = Button(
            text="New Match",
            font_size=sp(13),
            bold=True,
            background_normal="",
            background_color=(0.25, 0.36, 0.55, 1),
            color=(1, 1, 1, 1)
        )

        leave = Button(
            text="Leave",
            font_size=sp(13),
            bold=True,
            background_normal="",
            background_color=(0.5, 0.1, 0.1, 1),
            color=(1, 1, 1, 1)
        )

        buttons_row.add_widget(play_again)
        buttons_row.add_widget(new_match)
        buttons_row.add_widget(leave)
        layout.add_widget(buttons_row)

        self.end_popup = Popup(
            title="",
            content=layout,
            size_hint=(0.94, 0.27),
            auto_dismiss=False,
            background="",
            background_color=(0, 0, 0, 0),
            separator_height=0
        )

        play_again.bind(on_press=self.play_again)
        new_match.bind(on_press=self.new_match)
        leave.bind(on_press=self.leave_game)

        self.style_end_controls()
        self.end_popup.open()

    def style_end_controls(self):

        if not getattr(self, "end_layout", None):
            return

        self.refresh_panel(self.end_layout)

        for widget in self.end_layout.walk():
            if isinstance(widget, Label):
                widget.color = self.popup_text_color

    # --------------------------------------------------
    # RESTART ROUND
    # --------------------------------------------------

    def play_again(self, button):

        if getattr(self, "end_popup", None):
            self.end_popup.dismiss()
            self.end_popup = None

        self.game_over = False

        if self.last_winner:
            self.current_player = self.last_winner

        for i in range(9):
            self.dict[i] = " "

        self.root.remove_widget(self.board)
        self.board.canvas.after.clear()

        self.board = self.create_board()
        self.root.add_widget(self.board)

        self.player_label.text = (
            "Player " + self.current_player + "'s turn"
        )

        self.apply_theme()

    def new_match(self, button):

        self.x_score = 0
        self.o_score = 0
        self.last_winner = None
        self.update_score()
        self.play_again(button)

    def update_score(self):

        self.score_label.text = (
            "Player X: " + str(self.x_score)
            + "        Player O: " + str(self.o_score)
        )

    def leave_game(self, button):
        self.stop()

    # --------------------------------------------------
    # GRAPHICS HELPERS
    # --------------------------------------------------

    def update_bg(self, instance, value):
        self.bg.pos = instance.pos
        self.bg.size = instance.size

    def update_button_bg(self, button, value):
        button.bg_rect.pos = button.pos
        button.bg_rect.size = button.size

    def set_button_bg_color(self, button, color):
        button.bg_rect_color.rgba = color

    def draw_winning_line(self, combination):

        first_button = self.board.children[8 - combination[0]]
        last_button = self.board.children[8 - combination[2]]

        start_x = first_button.center_x
        start_y = first_button.center_y
        end_x = last_button.center_x
        end_y = last_button.center_y

        with self.board.canvas.after:
            Color(0.1, 1, 0.35, 0.22)
            Line(
                points=[start_x, start_y, end_x, end_y],
                width=14
            )

            Color(0.25, 1, 0.45, 1)
            Line(
                points=[start_x, start_y, end_x, end_y],
                width=5
            )

            Color(0.25, 1, 0.45, 1)
            Ellipse(
                pos=(start_x - sp(2.5), start_y - sp(2.5)),
                size=(sp(5), sp(5))
            )
            Ellipse(
                pos=(end_x - sp(2.5), end_y - sp(2.5)),
                size=(sp(5), sp(5))
            )

    # --------------------------------------------------
    # SETTINGS POPUP
    # --------------------------------------------------

    def open_settings(self, button):

        layout = BoxLayout(
            orientation="vertical",
            spacing=sp(12),
            padding=sp(16)
        )
        self.settings_layout = layout
        self.style_panel(layout)

        header = BoxLayout(
            orientation="horizontal",
            size_hint=(1, 0.25),
            spacing=sp(8)
        )

        self.settings_title_label = Label(
            text="SETTINGS",
            font_size=sp(24),
            bold=True,
            color=self.popup_text_color,
            halign="left",
            valign="middle"
        )
        self.settings_title_label.bind(
            size=lambda instance, value:
            setattr(instance, "text_size", value)
        )

        close_button = Button(
            text="X",
            font_size=sp(22),
            bold=True,
            size_hint=(None, 1),
            width=sp(45),
            background_normal="",
            background_color=(0.5, 0.1, 0.1, 1),
            color=(1, 1, 1, 1)
        )

        header.add_widget(self.settings_title_label)
        header.add_widget(close_button)
        layout.add_widget(header)

        self.sound_button = Button(
            text="",
            font_size=sp(16),
            background_normal=""
        )
        self.sound_button.bind(on_press=self.toggle_sound)
        layout.add_widget(self.sound_button)

        self.music_button = Button(
            text="",
            font_size=sp(16),
            background_normal=""
        )
        self.music_button.bind(on_press=self.toggle_music)
        layout.add_widget(self.music_button)

        self.theme_button = Button(
            text="",
            font_size=sp(16),
            background_normal=""
        )
        self.theme_button.bind(on_press=self.toggle_theme)
        layout.add_widget(self.theme_button)

        self.vibration_button = Button(
            text="",
            font_size=sp(16),
            background_normal=""
        )
        self.vibration_button.bind(
            on_press=self.toggle_vibration
        )
        layout.add_widget(self.vibration_button)

        self.settings_popup = Popup(
            title="",
            content=layout,
            size_hint=(0.88, 0.68),
            auto_dismiss=False,
            background="",
            background_color=(0, 0, 0, 0),
            separator_height=0
        )

        close_button.bind(
            on_press=self.settings_popup.dismiss
        )

        self.style_settings_controls()
        self.settings_popup.open()

    def style_settings_controls(self):

        if not getattr(self, "settings_layout", None):
            return

        self.refresh_panel(self.settings_layout)
        self.settings_title_label.color = self.popup_text_color

        self.sound_button.text = (
            "Sound Effects: ON"
            if self.sound_enabled else "Sound Effects: OFF"
        )

        self.music_button.text = (
            "Background Music: ON"
            if self.music_enabled else "Background Music: OFF"
        )

        self.theme_button.text = (
            "Theme: DARK"
            if self.dark_theme else "Theme: LIGHT"
        )

        self.vibration_button.text = (
            "Vibration: ON"
            if self.vibration_enabled else "Vibration: OFF"
        )

        for control in (
            self.sound_button,
            self.music_button,
            self.theme_button,
            self.vibration_button
        ):
            control.background_color = self.settings_button_color
            control.color = self.popup_text_color

    def toggle_sound(self, button):

        self.sound_enabled = not self.sound_enabled

        self.settings_store.put(
            "preferences",
            dark_theme=self.dark_theme,
            sound_enabled=self.sound_enabled,
            music_enabled=self.music_enabled
            )

        self.style_settings_controls()

    def toggle_music(self, button):

        self.music_enabled = not self.music_enabled

        if self.background_music:
            if self.music_enabled:
                self.background_music.play()
            else:
                self.background_music.stop()

        self.settings_store.put(
            "preferences",
            dark_theme=self.dark_theme,
            sound_enabled=self.sound_enabled,
            music_enabled=self.music_enabled
            )

        self.style_settings_controls()

    def toggle_theme(self, button):

        self.dark_theme = not self.dark_theme

        self.settings_store.put(
            "preferences",
            dark_theme=self.dark_theme,
            sound_enabled=self.sound_enabled,
            music_enabled=self.music_enabled
            )

        self.apply_theme()
        self.style_settings_controls()

    def toggle_vibration(self, button):

        self.vibration_enabled = not self.vibration_enabled

        if self.vibration_enabled:
            self.vibrate(0.08)

        self.style_settings_controls()

    # --------------------------------------------------
    # CLEANUP
    # --------------------------------------------------

    def on_stop(self):

        for sound in (
            self.background_music,
            self.tap_sound,
            self.win_sound,
            self.draw_sound
        ):
            if sound:
                sound.stop()
        
        # --------------------------------------------------
    # SPLASH SCREEN ANIMATION
    # --------------------------------------------------

    def update_splash_bg(self, instance, value):
        self.splash_bg.pos = instance.pos
        self.splash_bg.size = instance.size

    def start_splash_animation(self, dt):

        # Fade in the logo
        Animation(
            opacity=1,
            duration=0.8,
            transition="out_quad"
        ).start(self.logo)

        # Fade in the loading text
        Animation(
            opacity=1,
            duration=0.8,
            transition="out_quad"
        ).start(self.loading_label)
        
        
        Animation(
            opacity=1,
            duration=0.8,
            transition="out_quad"
        ).start(self.splash_title)

        # Animate the loading bar
        # Animate the loading bar
        loading_animation = Animation(
            value=100,
            duration=2.5,
            transition="in_out_quad"
            )
        loading_animation.bind(on_complete=self.open_game)
        
        loading_animation.start(self.loading_bar)

    def open_game(self, animation, widget):

        # Remove the splash screen
        self.root.clear_widgets()

        # Make the game widgets initially invisible
        for child in self.main_layout.children:
            child.opacity = 0

        # Show the game
        self.root.add_widget(self.main_layout)

        # Fade in the game widgets
        for child in self.main_layout.children:
            Animation(
                opacity=1,
                duration=0.65,
                transition="out_quad"
            ).start(child)


# --------------------------------------------------
# RUN GAME
# --------------------------------------------------

if __name__ == "__main__":
    TicTacToe().run()
